import pandas as pd

CITY_DATA = {
    'chicago': 'chicago.csv',
    'new york city': 'new_york_city.csv',
    'washington': 'washington.csv'
}


def load_data():
    """
    Load bikeshare data for a specified city and prepare time columns.
    Returns:
        df (DataFrame): Cleaned DataFrame with added time columns.
        city (str): Name of the selected city.
    """
    while True:
        city = input("Enter the city name (Chicago, New York City, Washington): ").lower()
        if city in CITY_DATA:
            df = pd.read_csv(CITY_DATA[city])
            df['Start Time'] = pd.to_datetime(df['Start Time'])
            df['month'] = df['Start Time'].dt.month
            df['day_of_week'] = df['Start Time'].dt.day_name()
            df['hour'] = df['Start Time'].dt.hour
            return df, city
        else:
            print("Invalid city name. Please try again.")


def display_raw_data(df):
    """
    Ask the user whether to display raw data, and show 5 rows at a time.

    Args:
        df (DataFrame): DataFrame to display data from.
    """
    row = 0
    while True:
        view_data = input('\nWould you like to see the raw data? Enter yes or no: ').lower()
        if view_data != 'yes':
            break
        print(df.iloc[row:row + 5])
        row += 5
        if row >= len(df):
            print("No more data to display.")
            break


def most_common_month(df):
    """
    Display the most common month in the dataset.

    Args:
        df (DataFrame): DataFrame with a 'month' column.
    """
    print("Most common month:", df['month'].mode()[0])


def most_common_day(df):
    """
    Display the most common day of the week.

    Args:
        df (DataFrame): DataFrame with a 'day_of_week' column.
    """
    print("Most common day of week:", df['day_of_week'].mode()[0])


def most_common_hour(df):
    """
    Display the most common start hour for trips.

    Args:
        df (DataFrame): DataFrame with an 'hour' column.
    """
    print("Most common start hour:", df['hour'].mode()[0])


def popular_times_of_travel():
    """
    Display menu for viewing statistics about the most frequent travel times.
    """
    while True:
        print("\n1 - Most common month")
        print("2 - Most common day of week")
        print("3 - Most common hour of day")
        print("4 - Return to main menu")

        choice = input("Enter your choice: ")
        if choice == '1':
            most_common_month(df)
        elif choice == '2':
            most_common_day(df)
        elif choice == '3':
            most_common_hour(df)
        elif choice == '4':
            return
        else:
            print("Invalid input. Please enter a number between 1 and 4.")


def most_common_start_station(df):
    """
    Display the most commonly used start station.

    Args:
        df (DataFrame): DataFrame with a 'Start Station' column.
    """
    print("Most common start station:", df['Start Station'].mode()[0])


def most_common_end_station(df):
    """
    Display the most commonly used end station.

    Args:
        df (DataFrame): DataFrame with an 'End Station' column.
    """
    print("Most common end station:", df['End Station'].mode()[0])


def most_common_trip(df):
    """
    Display the most frequent trip from start to end station.

    Args:
        df (DataFrame): DataFrame with 'Start Station' and 'End Station' columns.
    """
    df['Trip'] = df['Start Station'] + " -> " + df['End Station']
    print("Most common trip:", df['Trip'].mode()[0])


def popular_stations_and_trip():
    """
    Display menu for station and trip-related statistics.
    """
    while True:
        print("\n1 - Most common start station")
        print("2 - Most common end station")
        print("3 - Most common trip from start to end")
        print("4 - Return to main menu")

        choice = input("Enter your choice: ")
        if choice == '1':
            most_common_start_station(df)
        elif choice == '2':
            most_common_end_station(df)
        elif choice == '3':
            most_common_trip(df)
        elif choice == '4':
            return
        else:
            print("Invalid input. Please enter a number between 1 and 4.")


def total_travel_time(df):
    """
    Display the total duration of all trips.

    Args:
        df (DataFrame): DataFrame with a 'Trip Duration' column.
    """
    print("Total travel time (seconds):", df['Trip Duration'].sum())


def average_travel_time(df):
    """
    Display the average duration of trips.

    Args:
        df (DataFrame): DataFrame with a 'Trip Duration' column.
    """
    print("Average travel time (seconds):", df['Trip Duration'].mean())


def trip_duration():
    """
    Display menu for trip duration statistics.
    """
    while True:
        print("\n1 - Total travel time")
        print("2 - Average travel time")
        print("3 - Return to main menu")

        choice = input("Enter your choice: ")
        if choice == '1':
            total_travel_time(df)
        elif choice == '2':
            average_travel_time(df)
        elif choice == '3':
            return
        else:
            print("Invalid input. Please enter a number between 1 and 3.")


def count_of_each_user_type(df):
    """
    Display counts of each user type.

    Args:
        df (DataFrame): DataFrame with a 'User Type' column.
    """
    print("User types:\n", df['User Type'].value_counts())


def count_of_each_gender(df):
    """
    Display counts of gender, if available.

    Args:
        df (DataFrame): DataFrame with a 'Gender' column (may be missing).
    """
    if 'Gender' in df.columns:
        print("Gender counts:\n", df['Gender'].value_counts())
    else:
        print("Gender data not available for this city.")


def years_of_birth(df):
    """
    Display earliest, most recent, and most common year of birth.

    Args:
        df (DataFrame): DataFrame with a 'Birth Year' column (may be missing).
    """
    if 'Birth Year' in df.columns:
        print("Earliest year of birth:", int(df['Birth Year'].min()))
        print("Most recent year of birth:", int(df['Birth Year'].max()))
        print("Most common year of birth:", int(df['Birth Year'].mode()[0]))
    else:
        print("Birth year data not available for this city.")


def user_info():
    """
    Display menu for user demographic information.
    """
    while True:
        print("\n1 - Counts of each user type")
        print("2 - Counts of each gender")
        print("3 - Birth year stats")
        print("4 - Return to main menu")

        choice = input("Enter your choice: ")
        if choice == '1':
            count_of_each_user_type(df)
        elif choice == '2':
            count_of_each_gender(df)
        elif choice == '3':
            years_of_birth(df)
        elif choice == '4':
            return
        else:
            print("Invalid input. Please enter a number between 1 and 4.")


# MAIN EXECUTION
print("Welcome to my BikeShare Data Statistics")

df, selected_city = load_data()
display_raw_data(df)

while True:
    print("\nMAIN MENU")
    print("1 - Popular Times of Travel")
    print("2 - Popular Stations and Trip")
    print("3 - Trip Duration")
    print("4 - User Info")
    print("5 - Exit")

    choice = input("Enter the number of the operation you want to do: ")

    if choice == '1':
        popular_times_of_travel()
    elif choice == '2':
        popular_stations_and_trip()
    elif choice == '3':
        trip_duration()
    elif choice == '4':
        user_info()
    elif choice == '5':
        print("Exiting program. Goodbye!")
        break
    else:
        print("Invalid input. Please enter a number between 1 and 5.")
